import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
 import {WelcomeComponent} from './app.component' ;
 
  

@NgModule({
  declarations: [
     WelcomeComponent
   ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
 
  bootstrap:  [ WelcomeComponent  ],
  providers: [  ]
   
})
export class AppModule {}
