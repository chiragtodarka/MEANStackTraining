import {Component} from '@angular/core';

@Component({
    selector:'my-app',
    template : `welcome to Angular-2`

})
export class WelcomeComponent{

}